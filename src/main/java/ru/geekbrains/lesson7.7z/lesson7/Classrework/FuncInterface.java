package ru.geekbrains.lesson7.Classrework;

@FunctionalInterface
public interface FuncInterface {
    void doSomething(int a, String b);
}
