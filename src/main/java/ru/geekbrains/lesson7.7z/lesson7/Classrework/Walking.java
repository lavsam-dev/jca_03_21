package ru.geekbrains.lesson7.Classrework;

@FunctionalInterface
public interface Walking {
    void walk();
}
