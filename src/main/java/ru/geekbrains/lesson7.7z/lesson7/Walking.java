package ru.geekbrains.lesson7;

/**
 * Project jca_02_21
 *
 * @Author Alexander Grigorev
 * Created 22.03.2021
 * v1.0
 */
@FunctionalInterface
public interface Walking {
    void walk();
//    interface InnerInterface {}

}
