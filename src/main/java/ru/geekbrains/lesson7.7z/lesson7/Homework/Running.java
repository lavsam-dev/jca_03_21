package ru.geekbrains.lesson7.Homework;

public interface Running {
    void run(int length);
}
