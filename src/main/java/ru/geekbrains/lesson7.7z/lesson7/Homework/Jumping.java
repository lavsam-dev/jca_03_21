package ru.geekbrains.lesson7.Homework;

public interface Jumping {
    void jump(int height);
}
