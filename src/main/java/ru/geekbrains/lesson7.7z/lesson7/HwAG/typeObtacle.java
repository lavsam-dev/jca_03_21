package ru.geekbrains.lesson7.HwAG;

public enum typeObtacle {
    typeWall,
    typeTrack
}
