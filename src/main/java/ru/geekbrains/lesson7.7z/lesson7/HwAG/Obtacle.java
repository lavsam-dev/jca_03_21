package ru.geekbrains.lesson7.HwAG;

public interface Obtacle {
    int getLength();
    int getHeight();
    typeObtacle getTypeObtacle();
}
