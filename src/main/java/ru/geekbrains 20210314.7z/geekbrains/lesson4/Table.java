package ru.geekbrains.lesson4;

public class Table {
    String name;
}
