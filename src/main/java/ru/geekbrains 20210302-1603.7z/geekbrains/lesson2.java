package ru.geekbrains;

import java.util.Arrays;
import java.io.*;
import java.util.Scanner;

public class lesson2 {

    public static void main(String[] args) {
        //BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        //Scanner in = new Scanner(System.in);
        //String as;
        //as = reader.readLine();
        //int num = in.nextInt();
        int[] arrShift = {2, 4, 8, 16, 32, 64};
        //int[] arrShift = {2};

        System.out.println(Arrays.toString(arrShift));
        arrayShift(arrShift, -4);
        System.out.println(Arrays.toString(arrShift));

        byte[] bytes = {1, 2, 3, 4, 5, 12};
        byte[] bytes1 = {1, 2, 3, 4, 5, 12};
        byte[] copybytes = bytes;
//        System.out.println(bytes == copybytes);
//        System.out.println(Arrays.equals(bytes, bytes1));
//        System.out.println(Arrays.);
//        System.out.println(bytes);
//        System.out.println(bytes1);
//        System.out.println(Arrays.toString(bytes));

        byte b = 40;
        int i = 255;
        //i = b;
        //float f = i;
        b = (byte) i;
        //System.out.println(b);
/*
        for(byte b : bytes){
            System.out.println(++b);
        }
        for(byte b : bytes){
            System.out.println(--b);
        }

        for (int i = 0; i < bytes.length; i++){
            System.out.println(bytes[i]);
        }

        byte[][] byte2dArr = {
                {1,2,34},
                {4,6,7},
                {8,9,10}
        };

        for(byte[] bm : byte2dArr){
            for(byte b : bm){
                System.out.println(b);
            }
        }

        for(int i = 0; i < byte2dArr.length; i++){
            for(int j = 0; j < byte2dArr[i].length; j++){
                System.out.print(byte2dArr[i][j] + " ");
            }
            System.out.println();
        }*/
    }

    public static void arrayShift(int arr[], int n){
        if(arr.length > 1) {
            //System.out.println(Arrays.toString(arr));
            for (int j = 0; j < Math.abs(n); j++) {
                if (n > 0) for (int i = 0; i < arr.length - 1; i++) exchange(arr, i);
                else for (int i = arr.length - 2; i >= 0; i--) exchange(arr, i);
                //System.out.println(Arrays.toString(arr));
            }
        }
    }

    public static void exchange(int arr[], int i){
        int c = arr[i];
        arr[i] = arr[i+1];
        arr[i+1] = c;
    }

    public static void arrEx(){
        int[] arr = new int[5];
        arr[0] = 5;
        arr[1] = 15;
        arr[2] = 43;
        arr[4] = 257;
        arr[3] = 512;

        int[] arr1 = {2, 4, 8, 16, 32, 64};
        String[] strings = {"Petr", "Vasily"};

        int[][] squareArr = new int[5][];
        squareArr[0] = new int[10];
        squareArr[1] = new int[20];
        System.out.println(squareArr[2][1]);

        int[][] square2 = {
                {1, 2, 3},
                {4},
                {9, 3, 34, 56}
        };

    }

    private static void loopEx(){
        for(int i = 0, j = 10; i < 100; j += 10, i++){
            System.out.println(i + " " + j);
        }

//        int i = 0;
//        do {
//            System.out.println(i++);
//        } while (i < 10);

        /*int j = 0;
        while (true){
            j++;
            int i = 0;
            while ((true)){
                System.out.print(++i + " ");
                if(i == 10){
                    System.out.println(" ");
                    break;
                }
            }
            if(j == 5) break;
        }*/

    }

    private static void switchEx(){
        String name = "Ivan1";
        switch (name){
            case "Petr":
                System.out.println("Put letter to Petr");
                break;
            case "Ivan":
                System.out.println("Put letter to Ivan");
                break;
            case "Vitaly":
                System.out.println("Put letter to Vitaly");
                break;
            case "Vasily":
                System.out.println("Put letter to Vasily");
                break;
            case "Alex":
                System.out.println("Put letter to Alex");
                break;
            default:
                System.out.println("Nothing");
        }
    }
}
