package ru.geekbrains.lesson1;

public class Task1 {
    public static void main(String[] args){
        System.out.print("123456");
    }
}
